from __future__ import annotations

import re
import sys
import time
from pathlib import Path

try:
    import dns.resolver
    import dns.exception
    DNS_AVAILABLE = True
except ImportError:
    DNS_AVAILABLE = False

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QApplication, QWidget, QSplashScreen, QMainWindow,
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QTextEdit, QProgressBar, QFrame,
    QStatusBar, QGroupBox, QLineEdit, QCheckBox
)

# =============================================================================
# Constants
# =============================================================================
APP_NAME    = "Validation of Death"
ORG_NAME    = "Death's Head Software"
VERSION     = "1.0.0"

DARK_BG         = "#0a0a0a"
PANEL_BG        = "#111111"
BORDER_COLOR    = "#3a0000"
TEXT_COLOR      = "#e0e0e0"
RED_ACCENT      = "#cc0000"
RED_BRIGHT      = "#ff2222"
GREEN_ACCENT    = "#00cc44"
MUTED_TEXT      = "#666666"

MONO = "Courier New"

STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: {DARK_BG};
    color: {TEXT_COLOR};
    font-family: '{MONO}';
    font-size: 12px;
}}
QGroupBox {{
    border: 1px solid {BORDER_COLOR};
    border-radius: 0px;
    margin-top: 8px;
    padding-top: 6px;
    font-family: '{MONO}';
    font-size: 11px;
    color: {RED_ACCENT};
    font-weight: bold;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
}}
QPushButton {{
    background-color: {PANEL_BG};
    color: {RED_BRIGHT};
    border: 1px solid {BORDER_COLOR};
    padding: 6px 14px;
    font-family: '{MONO}';
    font-size: 12px;
    font-weight: bold;
    min-height: 26px;
}}
QPushButton:hover {{
    background-color: #1a0000;
    border: 1px solid {RED_ACCENT};
    color: #ff4444;
}}
QPushButton:pressed {{
    background-color: #2a0000;
}}
QPushButton:disabled {{
    color: {MUTED_TEXT};
    border: 1px solid #222222;
}}
QLabel {{
    color: {TEXT_COLOR};
    font-family: '{MONO}';
}}
QLineEdit {{
    background-color: {PANEL_BG};
    color: {TEXT_COLOR};
    border: 1px solid {BORDER_COLOR};
    padding: 4px 6px;
    font-family: '{MONO}';
    font-size: 12px;
    selection-background-color: {RED_ACCENT};
}}
QTextEdit {{
    background-color: {PANEL_BG};
    color: {TEXT_COLOR};
    border: 1px solid {BORDER_COLOR};
    font-family: '{MONO}';
    font-size: 11px;
    selection-background-color: {RED_ACCENT};
}}
QProgressBar {{
    background-color: {PANEL_BG};
    border: 1px solid {BORDER_COLOR};
    color: {TEXT_COLOR};
    text-align: center;
    font-family: '{MONO}';
    font-size: 11px;
    height: 18px;
}}
QProgressBar::chunk {{
    background-color: {RED_ACCENT};
}}
QStatusBar {{
    background-color: #0d0000;
    color: {MUTED_TEXT};
    font-family: '{MONO}';
    font-size: 11px;
    border-top: 1px solid {BORDER_COLOR};
}}
QCheckBox {{
    color: {TEXT_COLOR};
    font-family: '{MONO}';
    spacing: 6px;
}}
QCheckBox::indicator {{
    width: 13px;
    height: 13px;
    border: 1px solid {BORDER_COLOR};
    background-color: {PANEL_BG};
}}
QCheckBox::indicator:checked {{
    background-color: {RED_ACCENT};
    border: 1px solid {RED_BRIGHT};
}}
QFrame[frameShape="4"], QFrame[frameShape="5"] {{
    color: {BORDER_COLOR};
}}
"""

# =============================================================================
# Email Validation
# =============================================================================

# RFC 5322-ish regex — practical, not exhaustive
_EMAIL_RE = re.compile(
    r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+"
    r"@"
    r"[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?"
    r"(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*"
    r"\.[a-zA-Z]{2,}$"
)

def is_valid_email(addr: str) -> bool:
    addr = addr.strip()
    if not addr or len(addr) > 254:
        return False
    local, _, domain = addr.rpartition("@")
    if not local or not domain:
        return False
    if len(local) > 64:
        return False
    return bool(_EMAIL_RE.match(addr))

def parse_emails_from_text(text: str) -> list[str]:
    """
    Extract candidate email tokens from raw text.
    Handles comma-separated, newline-separated, space-separated, semicolon-separated.
    """
    # Normalise separators
    text = text.replace(",", " ").replace(";", " ").replace("|", " ")
    tokens = text.split()
    # Strip surrounding punctuation that isn't part of an email
    cleaned = []
    for t in tokens:
        t = t.strip("\"'<>()[]{}")
        if t:
            cleaned.append(t)
    return cleaned


# DNS/MX check — cached per domain so each domain is only looked up once
_mx_cache: dict[str, bool] = {}

def domain_has_mx(domain: str) -> bool:
    """Return True if the domain has at least one MX record. Cached."""
    domain = domain.lower()
    if domain in _mx_cache:
        return _mx_cache[domain]
    try:
        answers = dns.resolver.resolve(domain, "MX", lifetime=5)
        result = len(answers) > 0
    except (dns.exception.DNSException, Exception):
        result = False
    _mx_cache[domain] = result
    return result

# =============================================================================
# Worker Thread
# =============================================================================

class ValidationWorker(QThread):
    progress    = pyqtSignal(int)          # 0-100
    log_line    = pyqtSignal(str, str)     # (message, color)
    finished    = pyqtSignal(list, list)   # (valid, invalid)

    def __init__(self, input_path: str, dedupe: bool, lowercase: bool, mx_check: bool):
        super().__init__()
        self.input_path = input_path
        self.dedupe     = dedupe
        self.lowercase  = lowercase
        self.mx_check   = mx_check

    def run(self):
        valid, invalid = [], []
        try:
            raw = Path(self.input_path).read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            self.log_line.emit(f"[ERROR] Could not read file: {e}", RED_BRIGHT)
            self.finished.emit([], [])
            return

        candidates = parse_emails_from_text(raw)
        total = len(candidates)
        if total == 0:
            self.log_line.emit("[WARN]  No tokens found in file.", RED_BRIGHT)
            self.finished.emit([], [])
            return

        self.log_line.emit(f"[INFO]  {total} token(s) found — validating…", TEXT_COLOR)
        if self.mx_check:
            self.log_line.emit("[INFO]  MX lookup enabled — DNS queries in progress…", TEXT_COLOR)
        seen = set()

        for i, addr in enumerate(candidates):
            pct = int((i + 1) / total * 100)
            self.progress.emit(pct)

            if self.lowercase:
                addr = addr.lower()

            if not is_valid_email(addr):
                invalid.append(addr)
                self.log_line.emit(f"[FAIL]  {addr}", RED_BRIGHT)
                continue

            # MX check (only runs if syntax passed)
            if self.mx_check:
                domain = addr.rpartition("@")[2]
                if not domain_has_mx(domain):
                    invalid.append(addr)
                    self.log_line.emit(f"[NO MX] {addr}  ({domain})", "#ff8800")
                    continue

            if self.dedupe:
                key = addr.lower()
                if key in seen:
                    self.log_line.emit(f"[DUPE]  {addr}", MUTED_TEXT)
                    continue
                seen.add(key)

            valid.append(addr)
            self.log_line.emit(f"[VALID] {addr}", GREEN_ACCENT)

        self.finished.emit(valid, invalid)

# =============================================================================
# Splash Screen
# =============================================================================

def create_splash() -> QSplashScreen | None:
    try:
        splash_path = Path(__file__).parent / "splash.png"

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 30, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 30, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print(f"Splash error: {e}")
        return None

# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{VERSION}")
        self.setMinimumSize(860, 620)
        self._input_path  = ""
        self._output_path = ""
        self._valid: list[str]   = []
        self._invalid: list[str] = []
        self._worker: ValidationWorker | None = None
        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 10, 10, 6)
        root.setSpacing(8)

        # ---- Title bar ----
        title_lbl = QLabel(APP_NAME)
        title_lbl.setFont(QFont(MONO, 20, QFont.Weight.Bold))
        title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_lbl.setStyleSheet(f"color: {RED_BRIGHT}; padding: 4px 0;")
        root.addWidget(title_lbl)

        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {BORDER_COLOR};")
        root.addWidget(sep)

        # ---- Input/output file row ----
        io_group = QGroupBox("FILES")
        io_lay   = QVBoxLayout(io_group)
        io_lay.setSpacing(6)

        # Input
        in_row = QHBoxLayout()
        in_lbl = QLabel("Input :")
        in_lbl.setFixedWidth(60)
        self.in_edit = QLineEdit()
        self.in_edit.setPlaceholderText("Select a .txt file containing email addresses…")
        self.in_edit.setReadOnly(True)
        in_btn = QPushButton("Browse…")
        in_btn.setFixedWidth(90)
        in_btn.clicked.connect(self._browse_input)
        in_row.addWidget(in_lbl)
        in_row.addWidget(self.in_edit)
        in_row.addWidget(in_btn)
        io_lay.addLayout(in_row)

        # Output
        out_row = QHBoxLayout()
        out_lbl = QLabel("Output:")
        out_lbl.setFixedWidth(60)
        self.out_edit = QLineEdit()
        self.out_edit.setPlaceholderText("Select destination .txt for validated addresses…")
        self.out_edit.setReadOnly(True)
        out_btn = QPushButton("Browse…")
        out_btn.setFixedWidth(90)
        out_btn.clicked.connect(self._browse_output)
        out_row.addWidget(out_lbl)
        out_row.addWidget(self.out_edit)
        out_row.addWidget(out_btn)
        io_lay.addLayout(out_row)

        root.addWidget(io_group)

        # ---- Options ----
        opt_group = QGroupBox("OPTIONS")
        opt_lay   = QHBoxLayout(opt_group)
        opt_lay.setSpacing(20)
        self.cb_dedupe    = QCheckBox("Remove duplicates")
        self.cb_lowercase = QCheckBox("Normalise to lowercase")
        self.cb_inv_file  = QCheckBox("Also save rejected addresses")
        if DNS_AVAILABLE:
            self.cb_mx = QCheckBox("MX record lookup (DNS)")
        else:
            self.cb_mx = QCheckBox("MX record lookup (install dnspython)")
            self.cb_mx.setEnabled(False)
            self.cb_mx.setToolTip("pip install dnspython")
        self.cb_dedupe.setChecked(True)
        self.cb_lowercase.setChecked(True)
        opt_lay.addWidget(self.cb_dedupe)
        opt_lay.addWidget(self.cb_lowercase)
        opt_lay.addWidget(self.cb_mx)
        opt_lay.addWidget(self.cb_inv_file)
        opt_lay.addStretch()
        root.addWidget(opt_group)

        # ---- Log ----
        log_group = QGroupBox("LOG")
        log_lay   = QVBoxLayout(log_group)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMinimumHeight(200)
        log_lay.addWidget(self.log_box)
        root.addWidget(log_group, 1)

        # ---- Progress + stats ----
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        root.addWidget(self.progress_bar)

        stats_row = QHBoxLayout()
        self.lbl_valid   = QLabel("Valid: —")
        self.lbl_valid.setStyleSheet(f"color: {GREEN_ACCENT}; font-weight: bold;")
        self.lbl_invalid = QLabel("Rejected: —")
        self.lbl_invalid.setStyleSheet(f"color: {RED_BRIGHT}; font-weight: bold;")
        self.lbl_total   = QLabel("Total: —")
        self.lbl_total.setStyleSheet(f"color: {TEXT_COLOR};")
        stats_row.addWidget(self.lbl_valid)
        stats_row.addSpacing(20)
        stats_row.addWidget(self.lbl_invalid)
        stats_row.addSpacing(20)
        stats_row.addWidget(self.lbl_total)
        stats_row.addStretch()
        root.addLayout(stats_row)

        # ---- Action buttons ----
        btn_row = QHBoxLayout()
        self.run_btn  = QPushButton("▶  VALIDATE")
        self.run_btn.setFixedHeight(34)
        self.run_btn.clicked.connect(self._run_validation)
        self.run_btn.setEnabled(False)

        self.save_btn = QPushButton("💾  SAVE RESULTS")
        self.save_btn.setFixedHeight(34)
        self.save_btn.clicked.connect(self._save_results)
        self.save_btn.setEnabled(False)

        self.clear_btn = QPushButton("✕  CLEAR")
        self.clear_btn.setFixedHeight(34)
        self.clear_btn.clicked.connect(self._clear)
        self.clear_btn.setFixedWidth(100)

        btn_row.addWidget(self.run_btn)
        btn_row.addWidget(self.save_btn)
        btn_row.addWidget(self.clear_btn)
        root.addLayout(btn_row)

        # ---- Status bar ----
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage(f"{APP_NAME} v{VERSION}  |  {ORG_NAME}")

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------
    def _browse_input(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Input File", "",
            "Text Files (*.txt);;All Files (*)"
        )
        if path:
            self._input_path = path
            self.in_edit.setText(path)
            # Auto-suggest output path
            p = Path(path)
            self._output_path = str(p.parent / (p.stem + "_validated.txt"))
            self.out_edit.setText(self._output_path)
            self.run_btn.setEnabled(True)
            self.status.showMessage(f"Input: {path}")

    def _browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Validated Addresses", self._output_path or "",
            "Text Files (*.txt);;All Files (*)"
        )
        if path:
            self._output_path = path
            self.out_edit.setText(path)

    def _run_validation(self):
        if not self._input_path:
            return
        if not self._output_path:
            self._browse_output()
            if not self._output_path:
                return

        self._log_clear()
        self._valid   = []
        self._invalid = []
        _mx_cache.clear()
        self.progress_bar.setValue(0)
        self.save_btn.setEnabled(False)
        self.run_btn.setEnabled(False)
        self.lbl_valid.setText("Valid: —")
        self.lbl_invalid.setText("Rejected: —")
        self.lbl_total.setText("Total: —")

        self._log(f"[INFO]  Input  : {self._input_path}", TEXT_COLOR)
        self._log(f"[INFO]  Output : {self._output_path}", TEXT_COLOR)
        self._log(f"[INFO]  Dedupe : {self.cb_dedupe.isChecked()}  |  "
                  f"Lowercase: {self.cb_lowercase.isChecked()}  |  "
                  f"MX check: {self.cb_mx.isChecked()}", TEXT_COLOR)
        self._log("─" * 60, BORDER_COLOR)

        self._worker = ValidationWorker(
            self._input_path,
            self.cb_dedupe.isChecked(),
            self.cb_lowercase.isChecked(),
            self.cb_mx.isChecked()
        )
        self._worker.progress.connect(self.progress_bar.setValue)
        self._worker.log_line.connect(self._log)
        self._worker.finished.connect(self._on_finished)
        self._worker.start()
        self.status.showMessage("Validating…")

    def _on_finished(self, valid: list[str], invalid: list[str]):
        self._valid   = valid
        self._invalid = invalid
        total = len(valid) + len(invalid)

        self._log("─" * 60, BORDER_COLOR)
        self._log(f"[DONE]  Valid: {len(valid)}  |  Rejected: {len(invalid)}  |  Total: {total}", TEXT_COLOR)

        self.lbl_valid.setText(f"Valid: {len(valid)}")
        self.lbl_invalid.setText(f"Rejected: {len(invalid)}")
        self.lbl_total.setText(f"Total: {total}")

        self.run_btn.setEnabled(True)
        if valid:
            self.save_btn.setEnabled(True)
            self._auto_save()

        self.status.showMessage(
            f"Complete — {len(valid)} valid, {len(invalid)} rejected."
        )

    def _auto_save(self):
        """Auto-save to the selected output path."""
        try:
            Path(self._output_path).write_text(
                "\n".join(self._valid) + "\n", encoding="utf-8"
            )
            self._log(f"[SAVE]  Valid list written to: {self._output_path}", GREEN_ACCENT)

            if self.cb_inv_file.isChecked() and self._invalid:
                p = Path(self._output_path)
                inv_path = p.parent / (p.stem + "_rejected.txt")
                inv_path.write_text("\n".join(self._invalid) + "\n", encoding="utf-8")
                self._log(f"[SAVE]  Rejected list written to: {inv_path}", RED_BRIGHT)
        except Exception as e:
            self._log(f"[ERROR] Save failed: {e}", RED_BRIGHT)

    def _save_results(self):
        """Manual re-save via button."""
        if not self._valid:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Validated Addresses", self._output_path or "",
            "Text Files (*.txt);;All Files (*)"
        )
        if path:
            self._output_path = path
            self.out_edit.setText(path)
            self._auto_save()

    def _clear(self):
        self._log_clear()
        self._valid   = []
        self._invalid = []
        self._input_path  = ""
        self._output_path = ""
        self.in_edit.clear()
        self.out_edit.clear()
        self.progress_bar.setValue(0)
        self.lbl_valid.setText("Valid: —")
        self.lbl_invalid.setText("Rejected: —")
        self.lbl_total.setText("Total: —")
        self.run_btn.setEnabled(False)
        self.save_btn.setEnabled(False)
        self.status.showMessage(f"{APP_NAME} v{VERSION}  |  {ORG_NAME}")

    # ------------------------------------------------------------------
    # Logging helpers
    # ------------------------------------------------------------------
    def _log(self, msg: str, color: str = TEXT_COLOR):
        self.log_box.append(
            f'<span style="color:{color};font-family:{MONO};font-size:11px;">'
            f'{msg}</span>'
        )

    def _log_clear(self):
        self.log_box.clear()


# =============================================================================
# Entry Point
# =============================================================================

def load_app_icon() -> QIcon:
    """Load the skull icon from splash.png, falling back to a blank icon."""
    splash_path = Path(__file__).parent / "splash.png"
    if splash_path.exists():
        return QIcon(str(splash_path))
    return QIcon()


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLESHEET)

    icon = load_app_icon()
    app.setWindowIcon(icon)

    splash = create_splash()
    if splash:
        splash.show()
        msgs = ["Initializing…", "Loading modules…", "Preparing validator…", "Ready."]
        for msg in msgs:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            time.sleep(0.35)

    win = MainWindow()
    win.setWindowIcon(icon)
    win.show()

    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
